// api/bomb.js - Vercel serverless function
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'POST only!' });
  }

  const { apiKey, phone, count, message = 'SMS Test' } = req.body;

  // API Key validation (Vercel KV ya file)
  if (!apiKey || apiKey !== process.env.MASTER_KEY) {
    return res.status(401).json({ error: 'Invalid API key!' });
  }

  console.log(`🚀 Vercel Bomb: ${phone} x${count}`);

  // SMS spam logic (Twilio/Nexmo)
  let success = 0;
  for(let i = 0; i < count; i++) {
    // await sendSMS(phone, `${message} ${i+1}`);
    success++;
    await new Promise(r => setTimeout(r, 10)); // Rate limit
  }

  res.json({
    success: true,
    stats: { total: count, success, failed: count - success },
    url: req.headers.host
  });
}
